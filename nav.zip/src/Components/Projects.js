import React, { Component } from 'react'

class Projects extends Component {
  render() {
    return (
      <div><h3>
        You Chose Projects</h3></div>
    )
  }
}

export default Projects