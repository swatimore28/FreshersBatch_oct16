import React, { Component } from 'react'

class Home extends Component {
  render() {
    return (
      <div><h3>
        You Chose Home</h3></div>
    )
  }
}

export default Home