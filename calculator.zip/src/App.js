import './App.css';
import Calculator from './Components/Calculator/Calculator';

function App() {
  return (
    <div className="App">
      <Calculator/>
    </div>
  );
}

export default App;
